// 用户数据模拟
const users = [
  {
    _id: "user123",
    openid: "wx_openid_001",
    userInfo: {
      nickName: "小红",
      avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZmlsZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
      gender: 2
    },
    settings: {
      notification: {
        newEvents: true,
        favoriteSingerEvents: true,
        comments: false
      }
    },
    createTime: new Date("2024-01-15"),
    updateTime: new Date("2024-03-22")
  }
];

// 用户收藏
const favorites = [
  {
    _id: "fav001",
    userId: "user123",
    targetType: "singer", 
    targetId: "singer123",
    createTime: new Date("2024-03-01")
  },
  {
    _id: "fav002",
    userId: "user123",
    targetType: "singer", 
    targetId: "singer456",
    createTime: new Date("2024-03-05")
  },
  {
    _id: "fav003",
    userId: "user123",
    targetType: "event", 
    targetId: "event123",
    createTime: new Date("2024-03-10")
  }
];

// 用户评论
const comments = [
  {
    _id: "comment001",
    userId: "user123",
    userName: "小红",
    userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZmlsZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    targetType: "singer",
    targetId: "singer123",
    content: "Ella的声音真的很有感染力，上次的演出特别棒！",
    createTime: new Date("2024-03-15")
  },
  {
    _id: "comment002",
    userId: "user123",
    userName: "小红",
    userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZmlsZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    targetType: "event",
    targetId: "event123",
    content: "期待这次的R&B之夜，已经等不及了！",
    createTime: new Date("2024-03-20")
  }
];

// 模拟登录
function login(code) {
  // 实际应用中应该调用微信API换取openid
  // 这里我们直接返回模拟数据
  return {
    token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    userId: "user123",
    expireIn: 7200
  };
}

// 获取用户信息
function getUserInfo(userId) {
  return users.find(u => u._id === userId);
}

// 获取用户收藏
function getUserFavorites(userId, type) {
  return favorites
    .filter(f => f.userId === userId && (!type || f.targetType === type))
    .map(f => {
      // 实际应用中应该根据targetType和targetId去对应集合中查询详情
      return {
        _id: f._id,
        targetId: f.targetId,
        targetType: f.targetType,
        createTime: f.createTime
      };
    });
}

// 添加或取消收藏
function toggleFavorite(userId, targetType, targetId, isFavorite) {
  const existingIndex = favorites.findIndex(
    f => f.userId === userId && f.targetType === targetType && f.targetId === targetId
  );
  
  if (isFavorite && existingIndex === -1) {
    // 添加收藏
    const newFavorite = {
      _id: `fav${favorites.length + 1}`,
      userId,
      targetType,
      targetId,
      createTime: new Date()
    };
    favorites.push(newFavorite);
  } else if (!isFavorite && existingIndex !== -1) {
    // 取消收藏
    favorites.splice(existingIndex, 1);
  }
  
  return { isFavorited: isFavorite };
}

// 获取用户评论
function getUserComments(userId, type, limit = 10, skip = 0) {
  const filtered = comments.filter(
    c => c.userId === userId && (!type || c.targetType === type)
  );
  
  return filtered.slice(skip, skip + limit);
}

// 添加评论
function addComment(userId, targetType, targetId, content) {
  // 获取用户信息
  const user = getUserInfo(userId);
  if (!user) return null;
  
  const newComment = {
    _id: `comment${comments.length + 1}`,
    userId,
    userName: user.userInfo.nickName,
    userAvatar: user.userInfo.avatarUrl,
    targetType,
    targetId,
    content,
    createTime: new Date()
  };
  
  comments.push(newComment);
  return newComment;
}

// 更新用户设置
function updateUserSettings(userId, settings) {
  const userIndex = users.findIndex(u => u._id === userId);
  if (userIndex === -1) return null;
  
  users[userIndex].settings = {
    ...users[userIndex].settings,
    ...settings
  };
  users[userIndex].updateTime = new Date();
  
  return { settings: users[userIndex].settings };
}

module.exports = {
  users,
  favorites,
  comments,
  login,
  getUserInfo,
  getUserFavorites,
  toggleFavorite,
  getUserComments,
  addComment,
  updateUserSettings
};