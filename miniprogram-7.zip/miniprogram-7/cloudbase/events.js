// 活动数据模拟
const events = [
  {
    _id: "event123",
    title: "2046 R&B 之夜",
    imageUrl: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y29uY2VydHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    startTime: new Date("2025-04-15T21:00:00Z"),
    endTime: new Date("2025-04-15T23:00:00Z"),
    location: "2046 Live House",
    address: "北京市朝阳区三里屯街道",
    performers: [
      {
        id: "singer123",
        name: "Ella Johnson"
      },
      {
        id: "singer456",
        name: "Marcus Harper"
      }
    ],
    description: "2046 R&B 之夜将带您进入一场沉浸式的音乐体验，我们邀请了知名R&B歌手Ella Johnson和Marcus Harper为您带来精彩的现场表演。在独特的音乐氛围中，您可以享受顶级的音乐表演，品尝精心调制的鸡尾酒，与志同道合的音乐爱好者共度美好夜晚。活动包括两位歌手的solo表演以及特别合作环节，不容错过！",
    status: "upcoming", // upcoming, ongoing, finished
    createTime: new Date("2025-03-01"),
    updateTime: new Date("2025-03-15")
  },
  {
    _id: "event456",
    title: "Soul Music Festival",
    imageUrl: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8Y29uY2VydHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    startTime: new Date("2025-04-22T19:30:00Z"),
    endTime: new Date("2025-04-22T22:30:00Z"),
    location: "2046 Live House",
    address: "北京市朝阳区三里屯街道",
    performers: [
      {
        id: "singer789",
        name: "Sarah Chen"
      },
      {
        id: "singer101",
        name: "James Wilson"
      }
    ],
    description: "Soul Music Festival带来一场音乐盛宴，融合了当代最优秀的Soul音乐人才。Sarah Chen将带来她最新专辑《Digital Soul》的首演，James Wilson则将演绎经典Funk作品以及他的新EP《Funk Revival》。夜晚将在充满活力的合奏中达到高潮，让我们一起沉浸在Soul音乐的无限魅力中。",
    status: "upcoming",
    createTime: new Date("2025-03-05"),
    updateTime: new Date("2025-03-20")
  },
  {
    _id: "event789",
    title: "Jazz & Cocktail Night",
    imageUrl: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8Y29uY2VydHxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    startTime: new Date("2025-04-29T20:00:00Z"),
    endTime: new Date("2025-04-29T23:00:00Z"),
    location: "2046 Live House",
    address: "北京市朝阳区三里屯街道",
    performers: [
      {
        id: "singer456",
        name: "Marcus Harper"
      },
      {
        id: "singer123",
        name: "Ella Johnson"
      }
    ],
    description: "Jazz & Cocktail Night将为您带来一个轻松、优雅的夜晚，在品尝精心调制的特色鸡尾酒的同时，聆听Marcus Harper和Ella Johnson带来的爵士音乐演出。这个晚上，他们将合作演绎经典爵士乐作品，以及融合了R&B元素的创新曲目，为您呈现一场独特的听觉盛宴。",
    status: "upcoming",
    createTime: new Date("2025-03-10"),
    updateTime: new Date("2025-03-25")
  }
];

// 根据类型获取活动列表
function getEventsByType(type = 'upcoming', limit = 10, skip = 0) {
  let result;
  
  switch (type) {
    case 'popular':
      // 假设我们有一个计算热度的算法，这里简单模拟
      result = [...events].sort(() => 0.5 - Math.random());
      break;
    case 'favorite':
      // 实际应该根据用户ID查询收藏的活动，这里简单返回
      result = events.slice(0, 2);
      break;
    case 'upcoming':
    default:
      // 按时间升序排序
      result = [...events].sort((a, b) => a.startTime - b.startTime);
      break;
  }
  
  return result.slice(skip, skip + limit);
}

// 获取活动详情
function getEventDetail(eventId) {
  return events.find(e => e._id === eventId);
}

module.exports = {
  events,
  getEventsByType,
  getEventDetail
};