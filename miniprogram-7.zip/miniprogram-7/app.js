// app.js
const usersService = require('./services/users');
const api = require('./services/api');

App({
  onLaunch() {
    // 初始化用户登录状态
    this.checkLoginStatus();
  },

  // 检查登录状态
  checkLoginStatus() {
    try {
      // 从本地存储获取token和userId
      const token = wx.getStorageSync('token');
      const userId = wx.getStorageSync('userId');
      
      if (token && userId) {
        // 设置API服务的token和userId
        api.setUserInfo(token, userId);
        
        // 获取用户信息
        wx.getUserInfo({
          success: res => {
            this.globalData.userInfo = res.userInfo;
            this.globalData.isLoggedIn = true;
            
            // 通知已登录的页面
            if (this.userInfoReadyCallback) {
              this.userInfoReadyCallback(res);
            }
          },
          fail: () => {
            // 获取用户信息失败，可能是未授权或token过期
            this.logout();
          }
        });
      }
    } catch (e) {
      console.error('检查登录状态出错:', e);
    }
  },

  // 登录
  login(userInfo, callback) {
    wx.login({
      success: res => {
        if (res.code) {
          // 发送 res.code 到后台换取 token
          usersService.login(res.code, userInfo)
            .then(loginResult => {
              // 保存token和userId
              const { token, userId } = loginResult.data;
              wx.setStorageSync('token', token);
              wx.setStorageSync('userId', userId);
              
              // 设置全局状态
              this.globalData.userInfo = userInfo;
              this.globalData.isLoggedIn = true;
              
              // 回调
              callback && callback(null, loginResult);
            })
            .catch(err => {
              console.error('登录失败:', err);
              callback && callback(err);
            });
        } else {
          console.error('微信登录失败:', res);
          callback && callback(new Error('微信登录失败'));
        }
      },
      fail: err => {
        console.error('wx.login调用失败:', err);
        callback && callback(err);
      }
    });
  },

  // 退出登录
  logout() {
    // 清除本地存储
    wx.removeStorageSync('token');
    wx.removeStorageSync('userId');
    
    // 重置全局状态
    this.globalData.userInfo = null;
    this.globalData.isLoggedIn = false;
    
    // 重置API服务的token和userId
    api.setUserInfo(null, null);
  },

  globalData: {
    userInfo: null,
    isLoggedIn: false
  }
})
