// singer-detail/index.js
const singersService = require('../../services/singers');
const usersService = require('../../services/users');

Page({
  data: {
    singer: null,
    isLoading: true,
    loadingFailed: false,
    isFavorited: false,
    isLoggedIn: false
  },

  onLoad(options) {
    this.singerId = options.id;
    this.loadData();
    
    // 检查登录状态
    this.setData({
      isLoggedIn: usersService.isLoggedIn()
    });
  },

  onPullDownRefresh() {
    this.loadData(() => {
      wx.stopPullDownRefresh();
    });
  },

  // 加载歌手详情
  loadData(callback) {
    this.setData({ isLoading: true, loadingFailed: false });
    
    singersService.getSingerDetail(this.singerId)
      .then(res => {
        // 处理日期显示格式
        const singer = res.data;
        if (singer.performances) {
          singer.performances = singer.performances.map(perf => {
            const date = new Date(perf.date);
            perf.formattedDate = `${date.getMonth() + 1}月${date.getDate()}日 ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
            return perf;
          });
        }
        
        this.setData({ 
          singer: singer,
          isLoading: false
        });
      })
      .catch(err => {
        console.error('获取歌手详情失败:', err);
        this.setData({ 
          isLoading: false,
          loadingFailed: true
        });
        wx.showToast({
          title: '加载失败，请重试',
          icon: 'none'
        });
      })
      .finally(() => {
        callback && callback();
      });
  },

  // 收藏/取消收藏歌手
  toggleFavorite() {
    if (!this.data.isLoggedIn) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    
    const newState = !this.data.isFavorited;
    this.setData({ isFavorited: newState });
    
    singersService.toggleFavoriteSinger(this.singerId, newState)
      .then(() => {
        wx.showToast({
          title: newState ? '收藏成功' : '已取消收藏',
          icon: 'success'
        });
      })
      .catch(err => {
        console.error('收藏操作失败:', err);
        // 恢复状态
        this.setData({ isFavorited: !newState });
        wx.showToast({
          title: '操作失败，请重试',
          icon: 'none'
        });
      });
  },

  // 分享
  onShare() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },
  
  // 评论
  goToComment() {
    if (!this.data.isLoggedIn) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    
    // 实际应用中可以跳转到评论页面
    wx.showToast({
      title: '评论功能开发中',
      icon: 'none'
    });
  },
  
  // 点击演出项目
  onPerformanceTap(e) {
    const { eventid } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/event-detail/index?id=${eventid}`
    });
  },
  
  // 返回上一页
  onBack() {
    wx.navigateBack();
  },
  
  // 分享给朋友
  onShareAppMessage() {
    const singer = this.data.singer;
    return {
      title: singer ? `${singer.name} - 2046 R&B bar` : '2046 R&B bar',
      path: `/pages/singer-detail/index?id=${this.singerId}`
    };
  },
  
  // 分享到朋友圈
  onShareTimeline() {
    const singer = this.data.singer;
    return {
      title: singer ? `${singer.name} - 2046 R&B bar` : '2046 R&B bar',
      query: `id=${this.singerId}`
    };
  }
});