// index.js - 歌手页面
const singersService = require('../../services/singers');

Page({
  data: {
    recommendedSingers: [],
    latestSingers: [],
    isLoading: true,
    searchValue: '',
    loadingFailed: false
  },

  onLoad() {
    this.loadData();
  },

  onPullDownRefresh() {
    this.loadData(() => {
      wx.stopPullDownRefresh();
    });
  },

  // 加载数据
  loadData(callback) {
    this.setData({ isLoading: true, loadingFailed: false });
    
    Promise.all([
      singersService.getRecommendedSingers(),
      singersService.getLatestSingers()
    ])
    .then(([recommendedRes, latestRes]) => {
      this.setData({
        recommendedSingers: recommendedRes.data.singers,
        latestSingers: latestRes.data.singers,
        isLoading: false
      });
    })
    .catch(err => {
      console.error('获取歌手数据失败:', err);
      this.setData({ 
        isLoading: false,
        loadingFailed: true
      });
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
    })
    .finally(() => {
      callback && callback();
    });
  },

  // 点击歌手卡片
  handleSingerTap(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/singer-detail/index?id=${id}`
    });
  },

  // 搜索输入
  onSearchInput(e) {
    this.setData({
      searchValue: e.detail.value
    });
  },

  // 执行搜索
  onSearch() {
    // 实际应用中应该调用搜索API
    wx.showToast({
      title: `搜索: ${this.data.searchValue}`,
      icon: 'none'
    });
  },

  // 点击重试
  onRetry() {
    this.loadData();
  }
})
