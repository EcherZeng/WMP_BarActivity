// profile/index.js
const usersService = require('../../services/users');

Page({
  data: {
    userInfo: null,
    isLoggedIn: false,
    activeTab: 'favorites', // favorites, activities, comments
    favorites: {
      singers: [],
      events: []
    },
    comments: [],
    isLoading: false
  },
  
  onLoad() {
    this.checkLoginStatus();
  },
  
  onShow() {
    // 每次显示页面都检查登录状态
    this.checkLoginStatus();
    
    // 如果已登录，加载数据
    if (this.data.isLoggedIn) {
      this.loadData();
    }
  },
  
  // 检查登录状态
  checkLoginStatus() {
    const isLoggedIn = usersService.isLoggedIn();
    this.setData({ isLoggedIn });
  },
  
  // 加载数据
  loadData() {
    this.setData({ isLoading: true });
    
    switch(this.data.activeTab) {
      case 'favorites':
        this.loadFavorites();
        break;
      case 'activities':
        // 实际应用中可加载用户活动
        this.setData({ isLoading: false });
        break;
      case 'comments':
        this.loadComments();
        break;
    }
  },
  
  // 加载收藏
  loadFavorites() {
    usersService.getFavorites()
      .then(res => {
        this.setData({
          favorites: {
            singers: res.data.singers || [],
            events: res.data.events || []
          },
          isLoading: false
        });
      })
      .catch(err => {
        console.error('获取收藏失败:', err);
        wx.showToast({
          title: '加载失败，请重试',
          icon: 'none'
        });
        this.setData({ isLoading: false });
      });
  },
  
  // 加载评论
  loadComments() {
    usersService.getComments()
      .then(res => {
        this.setData({
          comments: res.data.comments || [],
          isLoading: false
        });
      })
      .catch(err => {
        console.error('获取评论失败:', err);
        wx.showToast({
          title: '加载失败，请重试',
          icon: 'none'
        });
        this.setData({ isLoading: false });
      });
  },
  
  // Tab切换
  switchTab(e) {
    const tabType = e.currentTarget.dataset.type;
    if (this.data.activeTab !== tabType) {
      this.setData({
        activeTab: tabType
      }, () => {
        if (this.data.isLoggedIn) {
          this.loadData();
        }
      });
    }
  },
  
  // 登录
  login() {
    // 获取用户信息
    wx.getUserProfile({
      desc: '用于完善用户资料',
      success: (res) => {
        const userInfo = res.userInfo;
        
        // 调用登录接口
        wx.login({
          success: (loginRes) => {
            if (loginRes.code) {
              // 发送 code 到后台换取 token
              usersService.login(loginRes.code, userInfo)
                .then(loginResult => {
                  this.setData({
                    isLoggedIn: true,
                    userInfo: userInfo
                  });
                  
                  // 保存token和userId到本地存储
                  wx.setStorageSync('token', loginResult.data.token);
                  wx.setStorageSync('userId', loginResult.data.userId);
                  
                  // 加载数据
                  this.loadData();
                  
                  wx.showToast({
                    title: '登录成功',
                    icon: 'success'
                  });
                })
                .catch(err => {
                  console.error('登录失败:', err);
                  wx.showToast({
                    title: '登录失败，请重试',
                    icon: 'none'
                  });
                });
            } else {
              console.error('微信登录失败:', loginRes);
              wx.showToast({
                title: '微信登录失败',
                icon: 'none'
              });
            }
          },
          fail: (err) => {
            console.error('wx.login调用失败:', err);
            wx.showToast({
              title: '微信登录失败',
              icon: 'none'
            });
          }
        });
      },
      fail: (err) => {
        console.error('获取用户信息失败:', err);
      }
    });
  },
  
  // 退出登录
  logout() {
    wx.showModal({
      title: '提示',
      content: '确认退出登录？',
      success: (res) => {
        if (res.confirm) {
          usersService.logout();
          this.setData({
            isLoggedIn: false,
            userInfo: null
          });
          
          wx.showToast({
            title: '已退出登录',
            icon: 'success'
          });
        }
      }
    });
  },
  
  // 点击歌手卡片
  handleSingerTap(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/singer-detail/index?id=${id}`
    });
  },
  
  // 点击活动卡片
  handleEventTap(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/event-detail/index?id=${id}`
    });
  },
  
  // 进入个人信息页面
  goToUserInfo() {
    wx.showToast({
      title: '个人信息功能开发中',
      icon: 'none'
    });
  },
  
  // 进入消息通知页面
  goToNotifications() {
    wx.showToast({
      title: '消息通知功能开发中',
      icon: 'none'
    });
  },
  
  // 进入隐私设置页面
  goToPrivacySettings() {
    wx.showToast({
      title: '隐私设置功能开发中',
      icon: 'none'
    });
  },
  
  // 进入帮助与反馈页面
  goToHelp() {
    wx.showToast({
      title: '帮助与反馈功能开发中',
      icon: 'none'
    });
  }
})