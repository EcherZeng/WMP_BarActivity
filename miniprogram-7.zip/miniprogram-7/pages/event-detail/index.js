// event-detail/index.js
const eventsService = require('../../services/events');
const usersService = require('../../services/users');

Page({
  data: {
    event: null,
    isLoading: true,
    loadingFailed: false,
    isFavorited: false,
    isLoggedIn: false
  },
  
  onLoad(options) {
    this.eventId = options.id;
    this.loadData();
    
    // 检查登录状态
    this.setData({
      isLoggedIn: usersService.isLoggedIn()
    });
  },
  
  onPullDownRefresh() {
    this.loadData(() => {
      wx.stopPullDownRefresh();
    });
  },
  
  // 加载活动详情
  loadData(callback) {
    this.setData({ isLoading: true, loadingFailed: false });
    
    eventsService.getEventDetail(this.eventId)
      .then(res => {
        // 处理日期时间格式
        const event = res.data;
        
        const startTime = new Date(event.startTime);
        const endTime = new Date(event.endTime);
        
        event.formattedDate = `${startTime.getMonth() + 1}月${startTime.getDate()}日 ${startTime.getHours()}:${String(startTime.getMinutes()).padStart(2, '0')}-${endTime.getHours()}:${String(endTime.getMinutes()).padStart(2, '0')}`;
        
        this.setData({ 
          event: event,
          isLoading: false
        });
      })
      .catch(err => {
        console.error('获取活动详情失败:', err);
        this.setData({ 
          isLoading: false,
          loadingFailed: true
        });
        wx.showToast({
          title: '加载失败，请重试',
          icon: 'none'
        });
      })
      .finally(() => {
        callback && callback();
      });
  },
  
  // 收藏/取消收藏活动
  toggleFavorite() {
    if (!this.data.isLoggedIn) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    
    const newState = !this.data.isFavorited;
    this.setData({ isFavorited: newState });
    
    eventsService.toggleFavoriteEvent(this.eventId, newState)
      .then(() => {
        wx.showToast({
          title: newState ? '收藏成功' : '已取消收藏',
          icon: 'success'
        });
      })
      .catch(err => {
        console.error('收藏操作失败:', err);
        // 恢复状态
        this.setData({ isFavorited: !newState });
        wx.showToast({
          title: '操作失败，请重试',
          icon: 'none'
        });
      });
  },
  
  // 分享
  onShare() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },
  
  // 评论
  goToComment() {
    if (!this.data.isLoggedIn) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    
    // 实际应用中可以跳转到评论页面
    wx.showToast({
      title: '评论功能开发中',
      icon: 'none'
    });
  },
  
  // 前往歌手详情页
  goToSingerDetail(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/singer-detail/index?id=${id}`
    });
  },
  
  // 打开位置
  openLocation() {
    const { event } = this.data;
    if (!event) return;
    
    // 实际应用中应该有经纬度信息
    // 这里只是演示
    wx.showToast({
      title: '位置导航功能开发中',
      icon: 'none'
    });
  },
  
  // 返回上一页
  onBack() {
    wx.navigateBack();
  },
  
  // 分享给朋友
  onShareAppMessage() {
    const event = this.data.event;
    return {
      title: event ? `${event.title} - 2046 R&B bar` : '2046 R&B bar',
      path: `/pages/event-detail/index?id=${this.eventId}`
    };
  },
  
  // 分享到朋友圈
  onShareTimeline() {
    const event = this.data.event;
    return {
      title: event ? `${event.title} - 2046 R&B bar` : '2046 R&B bar',
      query: `id=${this.eventId}`
    };
  }
});