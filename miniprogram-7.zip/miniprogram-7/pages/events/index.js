// events/index.js
const eventsService = require('../../services/events');

Page({
  data: {
    events: [],
    activeTab: 'upcoming', // upcoming, popular, favorite
    isLoading: true,
    loadingFailed: false,
    searchValue: ''
  },
  
  onLoad() {
    this.loadData();
  },
  
  onShow() {
    // 每次显示页面时检查是否需要刷新收藏tab
    if (this.data.activeTab === 'favorite') {
      this.loadData();
    }
  },
  
  onPullDownRefresh() {
    this.loadData(() => {
      wx.stopPullDownRefresh();
    });
  },
  
  // 加载数据
  loadData(callback) {
    const { activeTab } = this.data;
    
    this.setData({ isLoading: true, loadingFailed: false });
    
    eventsService.getEventsList(activeTab)
      .then(res => {
        // 处理日期格式
        const events = res.data.events.map(event => {
          // 格式化日期为"月日 时:分"
          const date = new Date(event.date || event.startTime);
          event.formattedDate = `${date.getMonth() + 1}月${date.getDate()}日 ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
          return event;
        });
        
        this.setData({
          events,
          isLoading: false
        });
      })
      .catch(err => {
        console.error('获取活动列表失败:', err);
        this.setData({ 
          isLoading: false,
          loadingFailed: true
        });
        wx.showToast({
          title: '加载失败，请重试',
          icon: 'none'
        });
      })
      .finally(() => {
        callback && callback();
      });
  },
  
  // Tab切换
  switchTab(e) {
    const tabType = e.currentTarget.dataset.type;
    if (this.data.activeTab !== tabType) {
      this.setData({
        activeTab: tabType
      }, () => {
        this.loadData();
      });
    }
  },
  
  // 点击活动卡片
  handleEventTap(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/event-detail/index?id=${id}`
    });
  },
  
  // 搜索输入
  onSearchInput(e) {
    this.setData({
      searchValue: e.detail.value
    });
  },
  
  // 执行搜索
  onSearch() {
    // 实际应用中应该调用搜索API
    wx.showToast({
      title: `搜索: ${this.data.searchValue}`,
      icon: 'none'
    });
  },
  
  // 点击重试
  onRetry() {
    this.loadData();
  }
})