// API服务封装
const singersMock = require('../cloudbase/singers');
const eventsMock = require('../cloudbase/events');
const usersMock = require('../cloudbase/users');

// 全局配置
const config = {
  apiBase: 'https://api.bar2046.com', // 实际环境中的API地址
  useMock: true,                      // 是否使用Mock数据
  token: null,                        // 用户认证token
  userId: null                         // 用户ID
};

// 请求拦截器
function requestInterceptor(options) {
  if (config.token) {
    options.header = {
      ...options.header,
      'Authorization': `Bearer ${config.token}`
    };
  }
  return options;
}

// 响应拦截器
function responseInterceptor(response) {
  if (response.statusCode >= 200 && response.statusCode < 300) {
    return response.data;
  }
  
  // 处理错误
  const error = new Error(response.data.message || '请求失败');
  error.statusCode = response.statusCode;
  error.data = response.data;
  throw error;
}

// 发送HTTP请求
async function request(method, url, data = {}, options = {}) {
  if (config.useMock) {
    return mockRequest(method, url, data, options);
  }

  const fullUrl = /^https?:\/\//.test(url) ? url : `${config.apiBase}${url}`;
  
  const requestOptions = requestInterceptor({
    url: fullUrl,
    method,
    data,
    header: {
      'Content-Type': 'application/json',
      ...options.header
    },
    ...options
  });

  try {
    const response = await new Promise((resolve, reject) => {
      wx.request({
        ...requestOptions,
        success: resolve,
        fail: reject
      });
    });
    
    return responseInterceptor(response);
  } catch (error) {
    console.error('Request failed:', error);
    throw error;
  }
}

// 模拟请求处理
function mockRequest(method, url, data = {}, options = {}) {
  console.log(`[Mock API] ${method} ${url}`, data);
  
  return new Promise((resolve) => {
    setTimeout(() => {
      // 模拟网络延迟
      let response = null;
      
      // 歌手相关API
      if (url.startsWith('/api/v1/singers')) {
        response = handleSingersApi(url, method, data);
      } 
      // 活动相关API
      else if (url.startsWith('/api/v1/events')) {
        response = handleEventsApi(url, method, data);
      } 
      // 用户相关API
      else if (url.startsWith('/api/v1/auth/login')) {
        response = handleLoginApi(data);
      }
      else if (url.startsWith('/api/v1/users')) {
        response = handleUsersApi(url, method, data);
      }
      else if (url.startsWith('/api/v1/comments')) {
        response = handleCommentsApi(url, method, data);
      }
      
      if (response) {
        resolve(formatResponse(response));
      } else {
        resolve(formatResponse({ error: 'Not Found' }, 404));
      }
    }, 300); // 模拟300ms延迟
  });
}

// 处理歌手相关API
function handleSingersApi(url, method, data) {
  // 获取推荐歌手列表
  if (url === '/api/v1/singers/recommended') {
    const limit = data.limit || 5;
    const skip = data.skip || 0;
    return {
      singers: singersMock.getRecommendedSingers(limit, skip)
    };
  }
  
  // 获取最新歌手列表
  if (url === '/api/v1/singers/latest') {
    const limit = data.limit || 5;
    const skip = data.skip || 0;
    return {
      singers: singersMock.getLatestSingers(limit, skip)
    };
  }
  
  // 获取歌手详情
  if (url.match(/^\/api\/v1\/singers\/[^/]+$/)) {
    const singerId = url.split('/').pop();
    return singersMock.getSingerDetail(singerId);
  }
  
  // 收藏/取消收藏歌手
  if (url.match(/^\/api\/v1\/singers\/[^/]+\/favorite$/) && method === 'POST') {
    const singerId = url.split('/')[4];
    const isFavorite = data.favorite;
    return usersMock.toggleFavorite(config.userId, 'singer', singerId, isFavorite);
  }
  
  return null;
}

// 处理活动相关API
function handleEventsApi(url, method, data) {
  // 获取活动列表
  if (url === '/api/v1/events') {
    const type = data.type || 'upcoming';
    const limit = data.limit || 10;
    const skip = data.skip || 0;
    return {
      events: eventsMock.getEventsByType(type, limit, skip)
    };
  }
  
  // 获取活动详情
  if (url.match(/^\/api\/v1\/events\/[^/]+$/)) {
    const eventId = url.split('/').pop();
    return eventsMock.getEventDetail(eventId);
  }
  
  // 收藏/取消收藏活动
  if (url.match(/^\/api\/v1\/events\/[^/]+\/favorite$/) && method === 'POST') {
    const eventId = url.split('/')[4];
    const isFavorite = data.favorite;
    return usersMock.toggleFavorite(config.userId, 'event', eventId, isFavorite);
  }
  
  return null;
}

// 处理登录API
function handleLoginApi(data) {
  const loginResult = usersMock.login(data.code);
  // 设置全局token和userId
  if (loginResult) {
    config.token = loginResult.token;
    config.userId = loginResult.userId;
  }
  return loginResult;
}

// 处理用户相关API
function handleUsersApi(url, method, data) {
  // 获取用户收藏列表
  if (url === '/api/v1/users/me/favorites') {
    const type = data.type;
    const favorites = usersMock.getUserFavorites(config.userId, type);
    
    // 返回收藏的详细信息
    const result = { };
    if (type === 'singers' || !type) {
      result.singers = favorites
        .filter(f => f.targetType === 'singer')
        .map(f => singersMock.getSingerDetail(f.targetId))
        .filter(s => s !== null);
    }
    if (type === 'events' || !type) {
      result.events = favorites
        .filter(f => f.targetType === 'event')
        .map(f => eventsMock.getEventDetail(f.targetId))
        .filter(e => e !== null);
    }
    
    return result;
  }
  
  // 获取用户评论
  if (url === '/api/v1/users/me/comments') {
    const type = data.type;
    const limit = data.limit || 10;
    const skip = data.skip || 0;
    return {
      comments: usersMock.getUserComments(config.userId, type, limit, skip)
    };
  }
  
  // 更新用户设置
  if (url === '/api/v1/users/me/settings' && method === 'PUT') {
    return usersMock.updateUserSettings(config.userId, data);
  }
  
  return null;
}

// 处理评论相关API
function handleCommentsApi(url, method, data) {
  // 添加评论
  if (url === '/api/v1/comments' && method === 'POST') {
    return usersMock.addComment(
      config.userId,
      data.targetType,
      data.targetId,
      data.content
    );
  }
  
  return null;
}

// 格式化响应数据
function formatResponse(data, code = 200) {
  return {
    code,
    message: code === 200 ? '成功' : '失败',
    data
  };
}

// 设置初始值
function setUserInfo(token, userId) {
  config.token = token;
  config.userId = userId;
}

module.exports = {
  // HTTP方法
  get: (url, params = {}, options = {}) => request('GET', url, params, options),
  post: (url, data = {}, options = {}) => request('POST', url, data, options),
  put: (url, data = {}, options = {}) => request('PUT', url, data, options),
  delete: (url, data = {}, options = {}) => request('DELETE', url, data, options),
  
  // 工具方法
  setUserInfo,
  config
};