// 活动服务
const api = require('./api');

// 获取活动列表
function getEventsList(type = 'upcoming', limit = 10, skip = 0) {
  return api.get('/api/v1/events', { type, limit, skip });
}

// 获取活动详情
function getEventDetail(eventId) {
  return api.get(`/api/v1/events/${eventId}`);
}

// 收藏/取消收藏活动
function toggleFavoriteEvent(eventId, isFavorite) {
  return api.post(`/api/v1/events/${eventId}/favorite`, { favorite: isFavorite });
}

module.exports = {
  getEventsList,
  getEventDetail,
  toggleFavoriteEvent
};