// 用户服务
const api = require('./api');

// 用户登录
function login(code, userInfo = null) {
  const data = { code };
  if (userInfo) {
    data.userInfo = userInfo;
  }
  return api.post('/api/v1/auth/login', data).then(res => {
    // 设置全局token和userId
    api.setUserInfo(res.data.token, res.data.userId);
    return res;
  });
}

// 获取用户收藏列表
function getFavorites(type) {
  return api.get('/api/v1/users/me/favorites', { type });
}

// 获取用户评论
function getComments(type, limit = 10, skip = 0) {
  return api.get('/api/v1/users/me/comments', { type, limit, skip });
}

// 添加评论
function addComment(targetType, targetId, content) {
  return api.post('/api/v1/comments', { targetType, targetId, content });
}

// 更新用户设置
function updateSettings(settings) {
  return api.put('/api/v1/users/me/settings', settings);
}

// 检查用户是否已登录
function isLoggedIn() {
  return !!(api.config.token && api.config.userId);
}

// 退出登录
function logout() {
  api.setUserInfo(null, null);
  // 可以清除本地存储的登录信息
  wx.removeStorageSync('token');
  wx.removeStorageSync('userId');
}

module.exports = {
  login,
  getFavorites,
  getComments,
  addComment,
  updateSettings,
  isLoggedIn,
  logout
};