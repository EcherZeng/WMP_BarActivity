// 歌手服务
const api = require('./api');

// 获取推荐歌手列表
function getRecommendedSingers(limit = 5, skip = 0) {
  return api.get('/api/v1/singers/recommended', { limit, skip });
}

// 获取最新歌手列表
function getLatestSingers(limit = 5, skip = 0) {
  return api.get('/api/v1/singers/latest', { limit, skip });
}

// 获取歌手详情
function getSingerDetail(singerId) {
  return api.get(`/api/v1/singers/${singerId}`);
}

// 收藏/取消收藏歌手
function toggleFavoriteSinger(singerId, isFavorite) {
  return api.post(`/api/v1/singers/${singerId}/favorite`, { favorite: isFavorite });
}

module.exports = {
  getRecommendedSingers,
  getLatestSingers,
  getSingerDetail,
  toggleFavoriteSinger
};